const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.post('/api/deposit', (req, res) => {
  const { amount, network, phoneNumber } = req.body;

  if (!amount || !network || !phoneNumber) {
    return res.status(400).json({ message: 'Taarifa hazijakamilika' });
  }

  console.log(`Kiasi: ${amount}, Mtandao: ${network}, Simu: ${phoneNumber}`);
  res.json({ success: true, message: `Tumeanza malipo ya TSh ${amount} kupitia ${network}` });
});

app.get('/', (req, res) => {
  res.send('CashPlay360 Backend Inafanya Kazi!');
});

app.listen(port, () => {
  console.log(`Server inaendeshwa kwenye port ${port}`);
});